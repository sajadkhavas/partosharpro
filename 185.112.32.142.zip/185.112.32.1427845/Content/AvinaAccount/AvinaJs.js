//========= start Alert ==============/
function avinaalert(alert, type, color) {
    if (type == null || type == 2) {
        typealert = "alert alert-danger";
    } else if (type == 1) {
        typealert = "alert alert-success";
    }
    var mycolor = "";
    if (color != null) {
        mycolor = 'style="color:' + color + '"';
    }
    if (alert != null) {
        const target = document.getElementById("alertDiv");
        document.getElementById("avinaalert").innerHTML = "<div class='" + typealert + "' id='passwordsNoMatchRegister' style='display:none;'> " + alert + "</div>";
        $('#passwordsNoMatchRegister').fadeIn(1000);
        setTimeout(function() {
            $('#passwordsNoMatchRegister').fadeOut(1000);
        }, 5000);
    }
};
$('.avcopy_link').click(function(e) {
    tag = $(this);
    text = tag.attr('data-link');
    navigator.clipboard.writeText(text);
    tag.text('کپی شد')
    setTimeout(function() {
        tag.text('کپی لینک')
    }, 1000)
});

function LoadSellerProducts(id1) {
    var procemessage = "<option value='0'> Please wait...</option>";
    var url = "/seller/GetProductsFromBrand";
    $.ajax({
        url: url,
        data: {
            brandid: id1
        },
        cache: false,
        type: "POST",

        success: function(data) {
            var markup = "<option value='0'>انتخاب محصول</option>";
            for (var x = 0; x < data.length; x++) {
                markup += "<option value=" + data[x].ProductId + ">" + data[x].ProductName + "</option>";
            }
            $("#proinfo").html(markup).show();
            AccessAddSellerProduct();
        },
        error: function(reponse) {
            avinaalert("error : " + reponse);
        }
    });
};

function AccessAddSellerProduct() {

    var proinfoElem = document.getElementById('proinfo');
    var chcoloridElem = document.getElementById('chcolorid');
    var chstockCount = document.getElementById('chstockCount').value.trim();
    var chprice = document.getElementById('chprice').value.trim();
    var proinfo = proinfoElem.options[proinfoElem.selectedIndex].value;
    var chcolorid = chcoloridElem.options[chcoloridElem.selectedIndex].value;
    var isValid = proinfo !== '' && chcolorid !== '' && chstockCount !== '' && chprice !== '';
    document.getElementById("addsellerpro").disabled = !isValid;
};

function avopensearch() {
    if ($('#avsbar').hasClass('d-none')) {
        $("#avsbar").removeClass("d-none");
    } else {
        $("#avsbar").addClass("d-none");
    }
};
//========= End Alert ==============/
//========= start Supermarket ==============/
function addprosp(avthiproid) {
    supermarket(avthiproid, 1);
};

function removeprosp(avthiproid) {
    supermarket(avthiproid, -1);
};

function supermarket(avthiproid, status) {
    $("button[name='avaddpro']").attr("disabled", true);
    var myproid = avthiproid;
    var updateboxid = '#refcount-' + myproid;
    $.ajax({
        type: 'POST',
        url: "/Home/Cart",
        data: {
            proid: myproid,
            fromcart: false,
            count: status,
            IsAjax: true
        },
        success: function(data) {
            $(updateboxid).html(data);
            $("button[name='avaddpro']").attr("disabled", false);
            $.ajax({
                type: 'POST',
                url: "/Home/updatebasket",
                success: function(databas) {
                    $("#headerBasketCounter").html(databas);
                },
                error: function(xhr, ajaxOptions, thrownError) {}
            });
        },
        error: function(xhr, ajaxOptions, thrownError) {
            if (xhr.status == 404) {
                document.getElementById("resultLoadingDiv").style.display = 'none';
                alert(thrownError);
            }
        }
    });
};
//========= End Supermarket ==============/
//========= start chart ==============/
$('.mychart').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/Home/ShowChart",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#chartdiv').append(data);
            $('#newaddress').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            alert('errrrr');
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End chart ==============/
//========= start Seller Chart ==============/
$('.mySellerchart').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/seller/ShowChart",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#Sellerchartdiv').append(data);
            $('#SellerchartdivClick').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End Seller Chart ==============/
//========= start Seller Des ==============/
$('.mySellerDescription').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/seller/ShowAdminDescription",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#Sellerdesdiv').append(data);
            $('#SellerDesdivClick').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End Seller Des ==============/
//========= start Seller EditPrice ==============/
$('.ModalEditPrice').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/seller/SellerEditPrice",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#SellerEditPricediv').append(data);
            $('#SellerEditPriceClick').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End Seller EditPrice ==============/
//========= start Seller Info ==============/
$('.ModalEditInfo').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/seller/SellerEditInfo",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#SellerEditInfodiv').append(data);
            $('#SellerEditInfoClick').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End Seller Info ==============/
$('.spemore').click(function() {
    $('#productTable').click();
    document.getElementById('productTable').scrollIntoView();
});

//========= start BetterPrice ==============/
$('.myBetterPrice').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    $.ajax({
        type: 'POST',
        url: "/Home/BetterPrice",
        data: {
            proid: myproid
        },
        success: function(data) {
            $('#BetterPricediv').html(data);
            $('#newaddress').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});
//========= End BetterPrice ==============/

//========= start AddToBasket ==============/
$(document).on('click', '.AddToBasketBtn', function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var myproid = $(this).attr("data-proid");
    var mycount = document.getElementById("procountch").value ? ? 1;
    $.ajax({
        type: 'POST',
        url: "/Home/Cart",
        data: {
            proid: myproid,
            fromcart: false,
            count: mycount,
            IsAjax: true
        },
        success: function(data) {
            $('#_BasketDive').html('');
            $('#_BasketDive').html(data);
            $('#BasketNotice_btn').click();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("خطا در افزودن به سبد خرید");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });
});

//========= End AddToBasket ==============/
//========= start addaddress ==============/
function changeTypecity(id1) {
    if (id1 != 0) {
        document.getElementById("mySubmitaddress").disabled = false;
    } else {
        document.getElementById("mySubmitaddress").disabled = true;
    }
};

function changeTypecity2(id1) {
    if (id1 != 0) {
        document.getElementById("mySubmitaddress2").disabled = false;
    } else {
        document.getElementById("mySubmitaddress2").disabled = true;
    }
};

function changeTypestatead(id1) {
    $.ajax({
        url: "/DropDownList/GetCities",
        type: "POST",
        data: {
            stateid: id1
        },
        success: function(data) {
            console.log(data); // حتما لاگ بگیرید ببینید چی میاد
            var markup = "<option value='0'>انتخاب شهر</option>";
            if (Array.isArray(data)) {
                data.forEach(function(city) {
                    markup += "<option value='" + city.cityId + "'>" + city.cityName + "</option>";
                });
            }
            $("#pages").html(markup).show();
        },
        error: function(xhr, status, error) {
            console.log(xhr, status, error);
            avinaalert("خطا در دریافت شهرها: " + error);
        }
    });
};

function changeTypestatead2(id1) {
    var procemessage = "<option value='0'> Please wait...</option>";
    var url = "/DropDownList/GetCities";
    $.ajax({
        url: url,
        data: {
            stateid: id1
        },
        cache: false,
        type: "POST",
        success: function(data) {
            var markup = "<option value='0'>انتخاب شهر</option>";
            for (var x = 0; x < data.length; x++) {
                markup += "<option value=" + data[x].CityId + ">" + data[x].CityName + "</option>";
            }

            $("#pages2").html(markup).show();
        },
        error: function(reponse) {
            avinaalert("error : " + reponse);
        }
    });
};

function changefinaladdress(id1) {
    $.ajax({
        url: "/account/AddAddressToFactorinprogress",
        data: {
            thisdata: id1
        },
        cache: false,
        type: "POST",
        success: function(data) {
            var avmsgg = data;
            window.location.reload();
        },
        error: function(reponse) {

        }
    });
};
$('.changedatedelivery').click(function() {

    document.getElementById("resultLoadingDiv").style.display = 'block';
    var dateid = $(this).attr("data-dateoffer");
    var datename = $(this).attr("data-offerval");
    document.getElementById("boxdeliverydateok").innerHTML = datename;

    $.ajax({
        type: 'POST',
        url: "/account/GetTimeDelivery",
        data: {
            date: dateid
        },
        success: function(data) {
            var markup = "";
            for (var x = 0; x < data.length; x++) {
                var sel = '';
                if (x == 0) {
                    sel = 'checked';
                }
                markup += "<p class='timeofferclass'><input data-timezone=' - ساعت : " + data[x].Name + "' class='radio_class timeofferclassinput changetimeradio' type='radio' value='" + data[x].Id + "' name='ddateid' " + sel + " /><i class='bi bi-watch timeofferclassi'></i> ساعت ارسال : " + data[x].Name + "</p>";
            }
            document.getElementById("offerdatehtml").innerHTML = "";
            $("#offerdatehtml").html(markup).show();
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });

});

function settimeinput() {
    var vartypeinfo = document.querySelector('input[name="ddateid"]:checked');
    var typeinfo = vartypeinfo.getAttribute('data-timezone');
    document.getElementById("unsettime").innerHTML = typeinfo;
};
$(".send-item").click(function() {
    $(".send-item").removeClass("active");
    $(this).addClass('active');
});
$('.unsettimebox').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';

    var datename = $(this).attr("data-unsettime");
    document.getElementById("unsettime").value = datename;
    document.getElementById("boxdeliverydateok").innerHTML = datename;
    document.getElementById("resultLoadingDiv").style.display = 'none';
});
//========= end addaddress ==============/
//========= start finalprice ==============/
function setprice() {
    document.getElementById("resultLoadingDiv").style.display = 'block';

    var vartypeinfo = document.querySelector('input[name="paymentstatus"]:checked');
    var pid = vartypeinfo.getAttribute('data-pid');
    var fhid = vartypeinfo.getAttribute('data-fhid');

    $.ajax({
        type: 'POST',
        url: "/account/addPostidToFactor",
        data: {
            pid: pid,
            fhid: fhid
        },
        success: function(data) {
            $('#detailbox').html(data);
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
        }
    });
};
//========= use wallet ==============/
function usewallet() {
    document.getElementById("resultLoadingDiv").style.display = 'block';

    var mystatus = 0;
    if (document.getElementById('walletchackbx').checked) {
        mystatus = 1;
    }

    //var vartypeinfo = document.querySelector('input[name="paymentstatus"]:checked');
    //var fhid = vartypeinfo.getAttribute('data-fhid');
    $.ajax({
        type: 'POST',
        url: "/account/UseWallet",
        data: {
            status: mystatus
        },
        success: function(data) {
            $('#detailbox').html(data);
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
        }
    });
};

function WalletStatus() {
    var element = document.getElementById('walletchackbx');
    if (typeof(element) != 'undefined' && element != null) {
        element.checked = false;
    }
};
$('.postpriceselect').change(function() {
    WalletStatus()
    setprice();
});
$('.wallet').change(function() {
    usewallet();
});
//========= End finalprice ==============/
//========= start Cart ==============/
$('.clink').change(function() {
    page = 0;
    _inCallback = false;
    $("#productList").html("");
    $('#SearchResult1').submit();
    /* window.scrollTo({ top: 380, behavior: 'smooth' });*/
});

function detail3() {
    $('#SearchResult1').submit();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};

function PushSort() {
    var sortid = document.getElementById('mysortfilter').options[document.getElementById('mysortfilter').selectedIndex].value;
    document.getElementById("sortstatus").value = sortid;
    _inCallback = false;
    page = 0;
    $('#SearchResult1').submit();
};

function PushSort2() {
    var sortid = document.querySelector('input[name="mysortfilter"]:checked').value;
    document.getElementById("sortstatus").value = sortid;
    _inCallback = false;
    page = 0;
    $('#SearchResult1').submit();
};

function PushSort22() {
    var sortid = 0;
    try {
        sortid = document.querySelector('input[name="mysortfilter22"]:checked').value;
    } catch (e) {
        var sortid = 0;
    }
    document.getElementById("sortstatus2").value = sortid;
    $('#SearchResult1').submit();
};

function setproductprice(s) {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    var adVALUE = s[s.selectedIndex].value;
    var adID = s[s.selectedIndex].id;
    $.ajax({
        type: 'POST',
        url: "/seller/ShowAllSallerList",
        data: {
            colorid: adVALUE,
            proid: adID
        },
        success: function(data) {
            $('#SellerListDiv').html('');
            $('#SellerListDiv').append(data);
            document.getElementById("resultLoadingDiv").style.display = 'none';
        },
        error: function() {
            avinaalert("error");
            document.getElementById("resultLoadingDiv").style.display = 'none';
        }
    });

};


//========= start populate pro ==============/
$('.addpopularbtn').click(function() {
    var myproid = $(this).attr("data-proid");
    var myurl = $(this).attr("data-url");
    $.ajax({
        type: 'POST',
        url: "/account/addajaxpopular",
        data: {
            proid: myproid,
            url: myurl
        },
        success: function(data) {
            if (data.length < 3) {
                avinaalert("کاربر گرامی ، برای افزودن به لیست  محصولات محبوب ثبت نام کنید");
            } else {
                avinaalert(data);
                if (data.includes('اضافه')) {
                    document.getElementById("populardetail").classList.remove('bi-heart');
                    document.getElementById("populardetail").classList.add('bi-heart-fill');
                    document.getElementById("populardetail").style.color = "#f03641";
                } else {
                    document.getElementById("populardetail").classList.remove('bi-heart-fill');
                    document.getElementById("populardetail").classList.add('bi-heart');
                    document.getElementById("populardetail").style.color = "#a33e97";
                }
            }
        },
        error: function() {
            avinaalert("کاربر گرامی ، برای افزودن به لیست  محصولات محبوب ثبت نام کنید");
        }
    });
});
//========= end populate pro ==============/

//========= start Cat ==============/
$('.morekambtn').click(function() {
    const seeMore = document.getElementById("seeMoreBtn");
    const article = document.getElementById("kambrand");
    article.classList.toggle("expanded");
    const expanded = article.classList.contains("expanded");
    if (expanded) {
        seeMore.innerHTML = "<i class='fa fa-angle-double-up'></i>";
    } else {
        seeMore.innerHTML = "<span style='font-size: 14px;position: relative;right: 4px;top: -2px;'>نمایش همه</span> ";
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
});
//========= end Cat ==============/

//========= start prodetail ==============/
$('.removeproindetail').click(function() {
    var procount = document.getElementById("procountch").value;

    var Coefficient = $(this).attr("data-Coefficient");
    var MinimumPurchase = $(this).attr("data-MinimumPurchase")

    if ((procount - Coefficient) > 0) {
        procount = (procount * 1) - (Coefficient * 1);
        document.getElementById("resultLoadingDiv").style.display = 'block';
        document.getElementById("procountch").disabled = true;
        document.getElementById("procountch").value = procount;
        document.getElementById("resultLoadingDiv").style.display = 'none';
        document.getElementById("procountch").disabled = false;
        detailcheckpro();
    }
});
$('.addproindetail').click(function() {
    document.getElementById("resultLoadingDiv").style.display = 'block';
    document.getElementById("procountch").disabled = true;
    var Coefficient = $(this).attr("data-Coefficient");
    var procount = document.getElementById("procountch").value;
    procount = (procount * 1) + (Coefficient * 1);
    document.getElementById("procountch").value = procount;
    document.getElementById("resultLoadingDiv").style.display = 'none';
    document.getElementById("procountch").disabled = false;
    detailcheckpro();
});
$('#procountch').change(function() {
    const procount = $(this).val();
    var ppriceid = document.getElementById("proid").value;
    document.getElementById("procountch").ariaReadOnly = true;
    changebasketcount(procount, ppriceid);
    document.getElementById("procountch").ariaReadOnly = false;


});
$('#procountchmob').change(function() {
    const procount = $(this).val();
    var ppriceid = document.getElementById("proidmob").value;
    document.getElementById("procountchmob").ariaReadOnly = true;
    changebasketcount(procount, ppriceid);
    document.getElementById("procountchmob").ariaReadOnly = false;
});

function changebasketcount(myprocount, proid) {
    const procount = myprocount;
    var ppriceid = proid;
    if (ppriceid > 0) {
        $.ajax({
            type: 'POST',
            url: "/Home/GetProductInfoFromPPrice",
            data: {
                myppriceid: ppriceid
            },
            success: function(data) {
                const myArray = data.split("^");
                var Coefficient = myArray[1];
                const ret = (procount * 1) % (Coefficient * 1);
                const min = myArray[2];
                if (((procount * 1) - min) < 1) {
                    avinaalert("حداقل تعداد خرید این محصول " + min + " عدد می باشد");
                    document.getElementById("procountch").value = min;
                } else if (ret != 0) {
                    avinaalert("خرید این محصول با تعداد ضریب " + Coefficient + " می باشد");
                    document.getElementById("procountch").value = min;
                } else {
                    detailcheckpro(myArray[0], myArray[3], procount);
                }
            },
            error: function() {
                avinaalert("error");
            }
        });
    }
};

function detailcheckpro(pid, mycolorid, myprocount) {
    var procount = myprocount;
    var productid = pid;
    if (procount > 0) {
        $.ajax({
            type: 'POST',
            url: "/Home/GetProductPrice",
            data: {
                procount: procount,
                proid: productid,
                colorid: mycolorid
            },
            success: function(data) {
                const myArray = data.split("^");
                document.querySelector(".NewPriceavdet").innerHTML = myArray[0];
                try {
                    document.querySelector(".NewPriceavdetmob").innerHTML = myArray[0];
                } catch (e) {

                }
            },
            error: function() {
                avinaalert("error");
            }
        });
    } else {
        document.getElementById("procountch").value = 1;
        document.getElementById("procountch").disabled = false;
    }
};
//========= end prodetail ==============/

//========= Start preloader ==============/
function init() {
    var imgDefer = document.getElementsByTagName('img');
    for (var i = 0; i < imgDefer.length; i++) {
        if (imgDefer[i].getAttribute('data-src')) {
            imgDefer[i].setAttribute('src', imgDefer[i].getAttribute('data-src'));
            imgDefer[i].classList.add("lazyloaded");
        }
    }
};
//========= end preloader ==============/
//========= Start alert ==============/
//const target = document.getElementById("alertDiv");
//window.onload = setInterval(() => target.style.opacity = '0', 3000)
//========= end alert ==============/

//========= start avina range ==============/
function numberWithCommas(x) {
    x = x.toString();
    var pattern = /(-?\d+)(\d{3})/;
    while (pattern.test(x))
        x = x.replace(pattern, "$1,$2");
    return x;
};

function controlFromInput(fromSlider, fromInput, toInput, controlSlider) {
    const [from, to] = getParsed(fromInput, toInput);
    fillSlider(fromInput, toInput, '#C6C6C6', '#5c5e60', controlSlider);
    if (from > to) {
        fromSlider.value = to;
        fromInput.value = to;
    } else {
        fromSlider.value = from;
    }
};

function controlToInput(toSlider, fromInput, toInput, controlSlider) {
    const [from, to] = getParsed(fromInput, toInput);
    fillSlider(fromInput, toInput, '#C6C6C6', '#5c5e60', controlSlider);
    setToggleAccessible(toInput);
    if (from <= to) {
        toSlider.value = to;
        toInput.value = 'تا قیمت : ' + numberWithCommas(to);
    } else {
        toInput.value = 'تا قیمت : ' + numberWithCommas(from);
    }
};

function controlFromSlider(fromSlider, toSlider, fromInput) {
    const [from, to] = getParsed(fromSlider, toSlider);
    fillSlider(fromSlider, toSlider, '#C6C6C6', '#5c5e60', toSlider);
    if (from > to) {
        fromSlider.value = to;
        fromInput.value = 'از قیمت : ' + numberWithCommas(to);;
    } else {
        fromInput.value = 'از قیمت : ' + numberWithCommas(from);
    }
};

function controlToSlider(fromSlider, toSlider, toInput) {
    const [from, to] = getParsed(fromSlider, toSlider);
    fillSlider(fromSlider, toSlider, '#C6C6C6', '#5c5e60', toSlider);
    setToggleAccessible(toSlider);
    if (from <= to) {
        toSlider.value = to;
        toInput.value = 'تا قیمت : ' + numberWithCommas(to);
    } else {
        toInput.value = from;
        toSlider.value = from;
    }
};

function getParsed(currentFrom, currentTo) {
    const from = parseInt(currentFrom.value, 10);
    const to = parseInt(currentTo.value, 10);
    return [from, to];
};

function fillSlider(from, to, sliderColor, rangeColor, controlSlider) {
    try {
        const rangeDistance = to.max - to.min;
        const fromPosition = from.value - to.min;
        const toPosition = to.value - to.min;
        controlSlider.style.background = `linear-gradient(
      to left,
      ${sliderColor} 0%,
      ${sliderColor} ${(fromPosition) / (rangeDistance) * 100}%,
      ${rangeColor} ${((fromPosition) / (rangeDistance)) * 100}%,
      ${rangeColor} ${(toPosition) / (rangeDistance) * 100}%, 
      ${sliderColor} ${(toPosition) / (rangeDistance) * 100}%, 
      ${sliderColor} 100%)`;
    } catch (e) {

    }
};

function setToggleAccessible(currentTarget) {
    try {
        const toSlider = document.querySelector('#toSlider');
        if (Number(currentTarget.value) <= 0) {
            toSlider.style.zIndex = 2;
        } else {
            toSlider.style.zIndex = 0;
        }
    } catch (e) {

    }
};
try {
    const fromSlider = document.querySelector('#fromSlider');
    const toSlider = document.querySelector('#toSlider');
    const fromInput = document.querySelector('#fromInput');
    const toInput = document.querySelector('#toInput');
    fillSlider(fromSlider, toSlider, '#C6C6C6', '#5c5e60', toSlider);
    setToggleAccessible(toSlider);
    fromSlider.oninput = () => controlFromSlider(fromSlider, toSlider, fromInput);
    toSlider.oninput = () => controlToSlider(fromSlider, toSlider, toInput);
    fromInput.oninput = () => controlFromInput(fromSlider, fromInput, toInput, toSlider);
    toInput.oninput = () => controlToInput(toSlider, fromInput, toInput, toSlider);
} catch (e) {

}
//========= end avina range ==============/

function changeClassfoot() {
    if (document.getElementById("footertextall").classList.contains('foottxth')) {
        document.getElementById("footertextall").classList.remove('foottxth');
        document.getElementById("footertextall").classList.add('foottxtu');
        document.getElementById("footertextall").classList.remove('avshadfoot2');
        document.getElementById("btnfootershow").innerHTML = "بستن";
    } else {
        document.getElementById("footertextall").classList.remove('foottxtu');
        document.getElementById("footertextall").classList.add('foottxth');
        document.getElementById("footertextall").classList.add('avshadfoot2');
        document.getElementById("btnfootershow").innerHTML = "مشاهده بیشتر";
    }
};

function changeClassfoot2() {
    if (document.getElementById("footertextallpg").classList.contains('foottxthpg')) {
        document.getElementById("footertextallpg").classList.remove('foottxthpg');
        document.getElementById("footertextallpg").classList.add('foottxtu');
        document.getElementById("footertextallpg").classList.remove('avshadfootpg2');
        document.getElementById("btnfootershow1").innerHTML = "بستن";
    } else {
        document.getElementById("footertextallpg").classList.remove('foottxtu');
        document.getElementById("footertextallpg").classList.add('foottxthpg');
        document.getElementById("footertextallpg").classList.add('avshadfootpg2');
        document.getElementById("btnfootershow1").innerHTML = "مشاهده بیشتر";
        window.scrollTo({
            top: 100,
            behavior: 'smooth'
        });
    }
};
$('.avcomreg').click(function() {
    var str = document.getElementById("username").value;
    var barcode7 = document.getElementById("barcode7").value;
    // convert persian digits [۰۱۲۳۴۵۶۷۸۹]
    var e = '۰'.charCodeAt(0);
    str = str.replace(/[۰-۹]/g, function(t) {
        return t.charCodeAt(0) - e;
    });
    // convert arabic indic digits [٠١٢٣٤٥٦٧٨٩]
    e = '٠'.charCodeAt(0);
    str = str.replace(/[٠-٩]/g, function(t) {
        return t.charCodeAt(0) - e;
    });
    var k = '۰'.charCodeAt(0);
    barcode7 = barcode7.replace(/[۰-۹]/g, function(t) {
        return t.charCodeAt(0) - k;
    });
    k = '٠'.charCodeAt(0);
    barcode7 = barcode7.replace(/[٠-٩]/g, function(t) {
        return t.charCodeAt(0) - k;
    });
    document.getElementById("username").value = str;
    document.getElementById("barcode7").value = barcode7;
    $("#sibform").click();
});
$('.avotp').click(function() {
    var str = document.getElementById("myfullname2").value;
    var e = '۰'.charCodeAt(0);
    str = str.replace(/[۰-۹]/g, function(t) {
        return t.charCodeAt(0) - e;
    });
    e = '٠'.charCodeAt(0);
    str = str.replace(/[٠-٩]/g, function(t) {
        return t.charCodeAt(0) - e;
    });
    var k = '۰'.charCodeAt(0);
    document.getElementById("myfullname2").value = str;
    $("#otpformsub").click();
});
$('.LikeComment').click(function() {
    var imyurl = $(this).attr("data-myurl");
    var istatus = $(this).attr("data-status");
    var ifaqid = $(this).attr("data-faqid");
    var yid = ifaqid + '-yes';
    var nid = ifaqid + '-no';
    $.ajax({
        type: 'POST',
        url: "/account/SetCommentLike",
        data: {
            myFaqId: ifaqid,
            myurl: imyurl,
            mystatus: istatus
        },
        success: function(data) {
            const myArray = data.split(",");
            if (myArray.length == 1) {
                window.location.href = "/Account";
            } else {
                document.getElementById(yid).innerHTML = myArray[0];
                document.getElementById(nid).innerHTML = myArray[1];
            }
        },
        error: function() {
            alert("error");

        }
    });
});
$('.showAnswer').click(function() {
    var boxid = $(this).attr("data-question-id");
    boxid = boxid + '-sh';
    document.getElementById(boxid).style.display = "block";
});
$('.hideAnswer').click(function() {
    var boxid = $(this).attr("data-question-id");
    boxid = boxid + '-sh';
    document.getElementById(boxid).style.display = "none";
});
$(document).on('keydown', '.avjustnumeric', function(e) {
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
        (e.keyCode == 65 && e.ctrlKey === true) ||
        (e.keyCode >= 35 && e.keyCode <= 40)) {
        return;
    }
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
    }
});
$(document).on('keydown', '.avjustfarsi', function(e) {
    if (e.key == 'Alt' || e.key == 'Shift' || e.key == 'Tab' || e.key == 'Backspace')
        return;
    if (!e.key.match(/^[0-9 ا آ ئ ب پ ت ث ج چ ح خ د ذ ر ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ه ی]+$/)) {
        e.preventDefault();
    }
});
$(document).on('keydown', '.avjustengelish', function(e) {
    if (e.key == 'Alt' || e.key == 'Shift' || e.key == 'Tab')
        return;
    if (!e.key.match(/^[0-9 a-z A-Z]+$/)) {
        e.preventDefault();
    }
});
$(document).on('keydown', '.avjustfarsiWithChar', function(e) {
    if (e.key == 'Shift' || e.key == 'Tab' || e.key == 'Backspace')
        return;
    if (!e.key.match(/^[0-9 ا آ ئ ب پ ت ث ج چ ح خ د ذ ر ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ه ی \-]+$/)) {
        e.preventDefault();
    }
});